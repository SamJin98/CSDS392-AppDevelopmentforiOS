//
//  assignment4App.swift
//  assignment4
//
//  Created by Sam Jin on 3/20/25.
//

import SwiftUI

@main
struct assignment4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
