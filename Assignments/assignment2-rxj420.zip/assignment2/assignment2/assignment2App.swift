//
//  assignment2App.swift
//  assignment2
//
//  Created by Sam Jin on 2/18/25.
//

import SwiftUI

@main
struct assignment2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
