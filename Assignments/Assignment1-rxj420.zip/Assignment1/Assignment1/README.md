# Assignment 1: Spartie Messages

## CSDS 392 - Spring 2025
**Author:** Ruilin Jin

---

## Overview
This repository contains the implementation for Assignment 1 of CSDS 392 (Spring 2025), focused on developing and handling Spartie messages.

## Reference
- [Check if Swift Text Field Contains Non-Whitespace - Stack Overflow](https://stackoverflow.com/questions/27768064/check-if-swift-text-field-contains-non-whitespace)

## Usage
Run the project in Xcode to execute and test the implementation.

