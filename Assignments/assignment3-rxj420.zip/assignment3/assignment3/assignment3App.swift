//
//  assignment3App.swift
//  assignment3
//
//  Created by Sam Jin on 3/3/25.
//

import SwiftUI

@main
struct assignment3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
