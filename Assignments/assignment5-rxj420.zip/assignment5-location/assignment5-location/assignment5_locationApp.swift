//
//  assignment5_locationApp.swift
//  assignment5-location
//
//  Created by Sam Jin on 4/12/25.
//

import SwiftUI

@main
struct assignment5_locationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
