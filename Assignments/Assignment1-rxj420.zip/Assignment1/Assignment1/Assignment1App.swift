//
//  Assignment1App.swift
//  Assignment1
//
//  Created by Sam Jin on 1/26/25.
//

import SwiftUI

@main
struct Assignment1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
